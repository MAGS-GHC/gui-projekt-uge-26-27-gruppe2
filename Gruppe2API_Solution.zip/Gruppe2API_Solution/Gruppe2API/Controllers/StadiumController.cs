using Microsoft.AspNetCore.Mvc;
using Models;

namespace Gruppe2API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StadiumController : ControllerBase
    {
       

        [HttpGet(Name = "GetWeatherForecast")]
        public Stadium Get()
        {
            return new ApiHelper.Helper().GetStadium(0);
        }
    }
}