﻿using static System.Collections.Specialized.BitVector32;
using System.Text.RegularExpressions;

namespace Models
{
    public class Stadium
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Section> Sections { get; set; }
        public List<Match> MatchList { get; set; }

        public Stadium()
        {
            Sections = new List<Section>();
            MatchList = new List<Match>();
        }
    }
}